import mmap
import os
import shutil
import stat
import subprocess
import sys

# assume git and cmake (64 bits) command is in PATH
GIT_CMD = "git"
CMAKE_CMD = "cmake"
NINJA_CMD = "ninja"

# ===== FBOX 健壮编译补丁（适配任意 Dart 版本，规避 proot 竞态 + OOM）=====
# 背景：容器编译路径（cmake+ninja 现场编译 DartVM）在 proot 环境有两大类失败，
#   都与具体 Dart 版本无关，是 proot 运行时环境固有的：
#   1. 高并发竞态：ninja 全核并行 fork/exec 200+ 个 cc1plus，在 proot ptrace/seccomp
#      模拟层触发 wait4/waitpid 竞态，偶发 ENOSYS → ninja SIGKILL(exit=137)，
#      或 cc1plus 偶发「头文件 No such file」误报（如 bits/types/clockid_t.h，
#      实际文件存在）。
#   2. OOM：DartVM 的 heap.cc/flow_graph*.cc 等巨型编译单元在 -O3 下单文件 RSS
#      可达 2~3GB，满核并行时多个 cc1plus 叠加，ARM64 真机内存峰值超限被内核
#      OOM killer 杀（exit=137）。
# 对策（确定性，不依赖 NINJAFLAGS 环境变量，手动跑 blutter.py 也生效）：
#   - 强制 -j1 串行编译：同时把并发 fork/exec 压到 1，规避竞态 + 降内存峰值。
#   - 失败自动重试：proot 竞态是偶发的，ninja 增量续编（已成功的 .o 不重编），
#     重跑只续编剩余单元，最终收敛成功。重试次数由环境变量 NINJA_RETRY 覆盖。
# 编译并发度：优先读环境变量 NINJA_JOBS，其次读 NINJAFLAGS 里的 -jN，兜底 1。
# 上层（LinuxViewModel）已按真机内存/核数动态算出安全的并行度写入环境变量；
# 串行 -j1 是为了防 OOM + 防 proot 竞态，但 -O2 降内存后适度并行可大幅缩短首次编译。
def _resolve_ninja_jobs() -> str:
    v = os.environ.get("NINJA_JOBS", "").strip()
    if v:
        return v
    # NINJAFLAGS 形如 '-j4'，解析其中的 -j 值
    import re as _re
    m = _re.search(r"-j\s*(\d+)", os.environ.get("NINJAFLAGS", ""))
    if m:
        return m.group(1)
    return "1"

FBOX_NINJA_JOBS = _resolve_ninja_jobs()
FBOX_NINJA_RETRY = int(os.environ.get("NINJA_RETRY", "12"))


def _run_ninja_robust(builddir: str):
    """串行 + 重试地执行 ninja，规避 proot 竞态偶发中断，最终收敛成功。"""
    last_exc = None
    for attempt in range(1, FBOX_NINJA_RETRY + 1):
        try:
            subprocess.run(
                [NINJA_CMD, "-j", FBOX_NINJA_JOBS],
                cwd=builddir, check=True,
            )
            return
        except subprocess.CalledProcessError as e:
            last_exc = e
            print(
                f"[fbox] ninja 第 {attempt}/{FBOX_NINJA_RETRY} 次中断（exit={e.returncode}），"
                f"增量续编剩余单元…", flush=True,
            )
    raise last_exc


def _fbox_preflight_check():
    """编译前自检：把 gcc 版本 / C++20 <format> / glibc 头文件三类隐性失败提前暴露。

    这些检查本来会在编译 DartVM 的 heap.cc 等文件时以晦涩的 fatal error 形式爆发
    （如 "bits/types/clockid_t.h: No such file or directory"），提前自检可给出明确、
    可诊断的报错，而不是让 ninja 跑到一半失败。
    """
    import tempfile

    def _sh(cmd):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return r.returncode, r.stdout + r.stderr
        except Exception as e:
            return -1, str(e)

    # 1. g++ 版本（blutter 硬性要求 >= 13，C++20 std::format）
    rc, out = _sh(["g++", "--version"])
    print(f"[fbox] g++ --version:\n{out}", flush=True)
    if rc != 0:
        raise RuntimeError("FBOX 自检失败：找不到 g++，请安装 g++>=13")

    # 2. C++20 <format> 支持（gcc-12 及更早缺失，会导致大量编译错误）
    with tempfile.TemporaryDirectory() as td:
        cpp = os.path.join(td, "t.cpp")
        with open(cpp, "w") as f:
            f.write('#include <format>\n#include <iostream>\nint main(){ std::cout << std::format("{}", 42); }\n')
        rc, out = _sh(["g++", "-std=c++20", cpp, "-o", os.path.join(td, "t")])
        if rc != 0:
            raise RuntimeError(
                f"FBOX 自检失败：g++ 不支持 C++20 <format>（需要 gcc>=13）。\n{out}"
            )

    # 3. glibc multiarch 头文件（clockid_t.h，heap.cc 等深 include 依赖）
    with tempfile.TemporaryDirectory() as td:
        cpp = os.path.join(td, "t.cpp")
        with open(cpp, "w") as f:
            f.write("#include <pthread.h>\n#include <time.h>\n#include <bits/types/clockid_t.h>\nint main(){ clockid_t c = CLOCK_REALTIME; (void)c; }\n")
        rc, out = _sh(["g++", cpp, "-o", os.path.join(td, "t")])
        if rc != 0:
            raise RuntimeError(
                f"FBOX 自检失败：glibc 头文件（bits/types/clockid_t.h）无法解析。\n"
                f"通常原因是 multiarch 头目录缺失或 libc6-dev 未装全。\n"
                f"修复：apt-get install -y --reinstall libc6-dev linux-libc-dev\n{out}"
            )

    print("[fbox] 编译前自检通过：g++>=13 + C++20 <format> + glibc 头文件齐备", flush=True)

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
CMAKE_TEMPLATE_FILE = os.path.join(SCRIPT_DIR, 'scripts', 'CMakeLists.txt')
CREATE_SRCLIST_FILE = os.path.join(SCRIPT_DIR, 'scripts', 'dartvm_create_srclist.py')
MAKE_VERSION_FILE = os.path.join(SCRIPT_DIR, 'scripts', 'dartvm_make_version.py')

SDK_DIR = os.path.join(SCRIPT_DIR, 'dartsdk')
BUILD_DIR = os.path.join(SCRIPT_DIR, 'build')

#DART_GIT_URL = 'https://dart.googlesource.com/sdk.git'
DART_GIT_URL = os.environ.get('DART_GIT_URL', 'https://github.com/dart-lang/sdk.git')
# 下载渠道：可用环境变量 DART_GIT_MIRRORS（逗号分隔）覆盖；clone 失败自动按顺序切换
DART_GIT_MIRRORS = [u.strip() for u in os.environ.get('DART_GIT_MIRRORS', '').split(',') if u.strip()] or [
    DART_GIT_URL,
    'https://ghfast.top/https://github.com/dart-lang/sdk.git',
    'https://gh-proxy.com/https://github.com/dart-lang/sdk.git',
    'https://gitclone.com/github.com/dart-lang/sdk.git',
    'https://ghproxy.net/https://github.com/dart-lang/sdk.git',
]

imp_replace_snippet = """import importlib.util
import importlib.machinery

def load_source(modname, filename):
    loader = importlib.machinery.SourceFileLoader(modname, filename)
    spec = importlib.util.spec_from_file_location(modname, filename, loader=loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module
"""

class DartLibInfo:
    def __init__(self, version: str, os_name: str, arch: str, has_compressed_ptrs = None, snapshot_hash = None):
        self.version = version
        self.os_name = os_name
        self.arch = arch
        self.snapshot_hash = snapshot_hash
        if has_compressed_ptrs is None:
            # use same as flutter default configuration
            # TODO: old Dart version has no pointer compression
            self.has_compressed_ptrs = os_name != 'ios'
        else:
            self.has_compressed_ptrs = has_compressed_ptrs
        self.lib_name = f'dartvm{version}_{os_name}_{arch}'


def checkout_dart(info: DartLibInfo):
    clonedir = os.path.join(SDK_DIR, 'v'+info.version)

    # if no version file,assume previous clone is failed. delete the whole directory and try again.
    version_file = os.path.join(clonedir, 'runtime', 'vm', 'version.cc')
    if os.path.exists(clonedir) and not os.path.exists(version_file):
        print('Delete incomplete clone directory ' + clonedir)
        def remove_readonly(func, path, _):
            os.chmod(path, stat.S_IWRITE)
            func(path)
        shutil.rmtree(clonedir, onerror=remove_readonly)
    
    # clone Dart source code
    if not os.path.exists(clonedir):
        # minimum clone repository at the target branch（多镜像自动切换）
        last_err = None
        cloned = False
        for url in DART_GIT_MIRRORS:
            try:
                print(f'[dartvm] git clone {url} (branch {info.version})', flush=True)
                subprocess.run([GIT_CMD, '-c', 'advice.detachedHead=false', 'clone', '-b', info.version, '--depth', '1', '--filter=blob:none', '--sparse', '--progress', url, clonedir], check=True, timeout=900)
                cloned = True
                break
            except Exception as e:
                last_err = e
                print(f'[dartvm] 该源 clone 失败，尝试下一个: {e}', flush=True)
                if os.path.exists(clonedir):
                    def remove_readonly(func, path, _):
                        os.chmod(path, stat.S_IWRITE)
                        func(path)
                    shutil.rmtree(clonedir, onerror=remove_readonly)
        if not cloned:
            raise last_err
        # checkout only needed sources (runtime and tools)
        # since Dart 3.3 "third_party/double-conversion" is moved to outside of "runtime" directory
        subprocess.run([GIT_CMD, 'sparse-checkout', 'set', 'runtime', 'tools', 'third_party/double-conversion'], cwd=clonedir, check=True)
        # delete some unnecessary files
        with os.scandir(clonedir) as it:
            for entry in it:
                if entry.is_file():
                    os.remove(entry.path)
                elif entry.is_dir() and entry.name == '.git':
                    # should ".git" directory be removed?
                    pass

        if info.snapshot_hash is None:
            # if running with Python 3.12, tools/utils.py should be patched to replace imp module with importlib
            # due to its remotion as stated in: https://docs.python.org/3.12/whatsnew/3.12.html#imp
            if sys.version_info[:2] >= (3, 12):
                utils_path = os.path.join(clonedir, "tools/utils.py")
                if os.path.exists(utils_path):
                    with open(utils_path, "r+") as f:
                        content = f.read()
                        # the python 3.12 warnings are fixed in https://github.com/dart-lang/sdk/commit/a100968232c7492ab0de26897ff019e5784d4d38
                        if r"match_against('^MAJOR (\d+)$', content)" in content:
                            # old Dart version
                            # replace invalid escape sequences strings with raw strings to avoid SyntaxWarning
                            # in future Python versions this warning will raise an error instead of warning
                            # as stated in: https://docs.python.org/3/whatsnew/3.12.html#other-language-changes
                            content = content.replace(" ' awk ", " r' awk ").replace("match_against('", "match_against(r'").replace("re.search('", "re.search(r'")
                            if "import imp\n" in content:
                                content = content.replace("import imp\n", imp_replace_snippet).replace("imp.load_source", "load_source")
                            f.seek(0)
                            f.truncate()
                            f.write(content)
            # make version
            subprocess.run([sys.executable, 'tools/make_version.py', '--output', 'runtime/vm/version.cc', '--input', 'runtime/vm/version_in.cc'], cwd=clonedir, check=True)
        else:
            subprocess.run([sys.executable, MAKE_VERSION_FILE, clonedir, info.snapshot_hash], check=True)
        
        if sys.platform == 'win32':
            # since Dart 3.8, RUNTIME_FUNCTION is declared when DART_HOST_OS_WINDOWS and TARGET_ARCH_ARM64 are set
            # patch "runtime/platform/unwinding_records.h" to remove the declaration
            vers = info.version.split('.', 2)
            if int(vers[0]) >= 3 and int(vers[1]) >= 8:
                with open(os.path.join(clonedir, 'runtime', 'platform', 'unwinding_records.h'), 'r+b') as f:
                    mm = mmap.mmap(f.fileno(), 0)
                    pos = mm.find(b'\n#if !defined(DART_HOST_OS_WINDOWS) || !defined(HOST_ARCH_ARM64)')
                    if pos != -1:
                        # replace "||" with "//" to comment out "!defined(HOST_ARCH_ARM64)"
                        mm[pos+36:pos+38] = b'//'
                    else:
                        # newer Dart version use static_assert for checking RUNTIME_FUNCTION size, comment out that line
                        pos = mm.find(b'\nstatic_assert(sizeof(')
                        if pos != -1:
                            mm[pos+1:pos+3] = b'//'
    
    return clonedir

# ===== FBOX_GCC13_FIX / FBOX_LARGEFILE64_FIX（随包内置，随包生效，不依赖运行时注入）=====
# 背景：GCC13+ 把 reinterpret_cast<T>(NULL) 判为非法（error: invalid cast），DartVM 源码中大量
#   使用该写法；同时新版 Dart 的 os_linux.cc 使用 off64_t/pread64，需要先定义 _LARGEFILE64_SOURCE。
# 说明：LinuxViewModel 的 GCC13_FIX_SCRIPT 会在运行时把同一钩子注入本文件，注入前用
#   'FBOX_GCC13_FIX' 标记做幂等判断；此处随包内置该标记后，运行时注入会自动跳过（不会重复注入）。
#   两处逻辑必须保持一致，修改任一处时请同步另一处。
def fbox_gcc13_fix(dartsdk_dir):
    import os, re
    _pat = re.compile(r'reinterpret_cast\s*<\s*((?:const\s+)?[A-Za-z_][A-Za-z0-9_:]*(?:\s*\*)*)\s*>\s*\(\s*NULL\s*\)')
    _marker = '#define _LARGEFILE64_SOURCE 1'
    _n = 0
    for _root, _, _files in os.walk(dartsdk_dir):
        for _fn in _files:
            if not _fn.endswith(('.cc', '.h', '.cpp', '.hpp')):
                continue
            _f = os.path.join(_root, _fn)
            try:
                _src = open(_f, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            _new = _pat.sub(lambda m: 'static_cast<%s>(nullptr)' % m.group(1), _src)
            if _new != _src:
                try:
                    open(_f, 'w', encoding='utf-8').write(_new)
                    _n += 1
                except Exception:
                    pass
                _src = _new
            # 只在真正用到 off64_t/pread64 且尚未定义宏的文件上插入，且必须独占一行
            # （历史上曾因把换行写成字面量 \n，导致 #include "vm/globals.h" 被吞掉 →
            #  DART_HOST_OS_LINUX 未定义 → os_linux.cc 函数体被 #if 跳过 → 空 .o）
            if 'off64_t' in _src or 'pread64' in _src:
                if _marker not in _src:
                    _lines = _src.splitlines(True)
                    _idx = None
                    for _i, _ln in enumerate(_lines):
                        if _ln.lstrip().startswith('#'):
                            _idx = _i
                            break
                    if _idx is None:
                        _lines.insert(0, _marker + '\n')
                    else:
                        _lines.insert(_idx, _marker + '\n')
                    try:
                        open(_f, 'w', encoding='utf-8').write(''.join(_lines))
                        _n += 1
                    except Exception:
                        pass
    return _n


def cmake_dart(info: DartLibInfo, target_dir: str):
    # ===== FBOX 编译前环境自检（把隐性失败变成显性、可诊断的报错）=====
    _fbox_preflight_check()

    # Dart 3.11.0+ requires C++20 https://github.com/dart-lang/sdk/commit/3ebbaf08fb9236023b8f37bb9e9de85a9be8e281
    # getting default cpp standard version for Dart SDK from "runtime/tools/run_clang_tidy.dart"
    #   because "build/config/compiler/BUILD.gn" is not fetched
    # example commit for changing cpp version https://github.com/dart-lang/sdk/commit/0a238b382891f8f3164d5ee561468e160f3c554f
    # Note: cpp20 will be used since Dart 3.7
    run_clang_tidy_file = os.path.join(target_dir, 'runtime', 'tools', 'run_clang_tidy.dart')
    with open(run_clang_tidy_file, 'r') as f:
        content = f.read()
        pos = content.find("-std=c++")
        # Note: very old Dart, there is no '-std=c++' option in run_clang_tidy.dart
        cpp_std = "17" if pos == -1 else content[pos+8:pos+10]
    
    # On windows, need developer command prompt for x64 (can check with "cl" command)
    # create dartsdk/vx.y.z/CMakefile.list
    with open(CMAKE_TEMPLATE_FILE, 'r') as f:
        code = f.read()
    with open(os.path.join(target_dir, 'CMakeLists.txt'), 'w') as f:
        f.write(code.replace('VERSION_PLACE_HOLDER', info.version).replace('CXX_STD_PLACE_HOLDER', cpp_std))

    # create dartsdk/vx.y.z/Config.cmake.in
    with open(os.path.join(target_dir, 'Config.cmake.in'), 'w') as f:
        f.write('@PACKAGE_INIT@\n\n')
        f.write('include ( "${CMAKE_CURRENT_LIST_DIR}/dartvmTarget.cmake" )\n\n')
    
    # generate source list
    subprocess.run([sys.executable, CREATE_SRCLIST_FILE, target_dir], check=True)
    # cmake -GNinja -Bout3.0.3 -DCMAKE_BUILD_TYPE=Release
    #   add -DTARGET_ARCH=x64 for analyzing x64 libapp.so
    #   add -DTARGET_OS=ios for analyzing ios App
    # Note: pointer compression feature is set from Flutter and no one change it when building app.
    #       so only one build of Dart runtime is enough
    builddir = os.path.join(BUILD_DIR, info.lib_name)
    subprocess.run([CMAKE_CMD, '-GNinja', '-B', builddir, f'-DTARGET_OS={info.os_name}', f'-DTARGET_ARCH={info.arch}', 
        f'-DCOMPRESSED_PTRS={1 if info.has_compressed_ptrs else 0}', '-DCMAKE_BUILD_TYPE=Release', '--log-level=NOTICE'], 
        cwd=target_dir, check=True)
    
    # build and install dart vm library to packages directory
    # 健壮编译：串行(-j1) + 自动重试，规避 proot 竞态偶发中断（见文件头 FBOX 补丁说明）。
    _run_ninja_robust(builddir)
    subprocess.run([CMAKE_CMD, '--install', '.'], cwd=builddir, check=True)

def fetch_and_build(info: DartLibInfo):
    outdir = checkout_dart(info)
    # GCC13 非法转换 + _LARGEFILE64_SOURCE 修补（详见 fbox_gcc13_fix 说明）
    try:
        fbox_gcc13_fix(outdir)
    except Exception:
        pass
    cmake_dart(info, outdir)

if __name__ == "__main__":
    ver = sys.argv[1]
    os_name = 'android' if len(sys.argv) < 3 else sys.argv[2]
    arch = 'arm64' if len(sys.argv) < 4 else sys.argv[3]
    snapshot_hash = None if len(sys.argv) < 5 else sys.argv[4]
    info = DartLibInfo(ver, os_name, arch, snapshot_hash=snapshot_hash)
    fetch_and_build(info)
