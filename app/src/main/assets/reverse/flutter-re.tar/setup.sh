#!/bin/sh
# ============================================================
#  FBox · Flutter 逆向工具链一键安装脚本（幂等版）
#  适用于 Debian Linux arm64（proot 容器）
#  运行方式：sh /root/flutter-re/setup.sh
#  特性：已安装的组件自动跳过，不会重复下载/升级，秒级完成
# ============================================================
set -e
PYPI="https://mirrors.aliyun.com/pypi/simple/"
MARK=/root/flutter-re/.installed

echo "==> 检测已安装状态…"
if [ -f "$MARK" ] && command -v cmake >/dev/null 2>&1 && command -v blutter >/dev/null 2>&1; then
    echo "工具链已安装（检测到 $MARK）。"
    echo "如需强制重装，请先执行： rm -f $MARK"
    exit 0
fi

echo "==> [1/6] 编译与基础工具（只补装缺失组件，避免重复升级）"
# Debian 用 dpkg-query 判断包是否已安装；rootfs 已预装大部分，此处兜底补装缺失项
missing=""
for p in python3 python3-pip git cmake ninja-build gcc g++ make pkg-config libicu-dev libcapstone-dev binutils file unzip curl ca-certificates; do
    dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing="$missing $p"
done
if [ -n "$missing" ]; then
    echo "  需安装:$missing"
    apt-get update >/dev/null 2>&1
    DEBIAN_FRONTEND=noninteractive apt-get install -y $missing
else
    echo "  全部已安装，跳过"
fi

echo "==> [2/6] Python 依赖（pyelftools/requests/dill/capstone）"
if python3 -c "import pyelftools, requests, dill, capstone" 2>/dev/null; then
    echo "  已安装，跳过"
else
    pip3 install --break-system-packages -i "$PYPI" pyelftools requests dill capstone
fi

echo "==> [3/6] frida-tools（动态插桩，备用）"
if command -v frida >/dev/null 2>&1; then
    echo "  已安装，跳过"
else
    pip3 install --break-system-packages -i "$PYPI" frida-tools || echo "  （frida-tools 安装失败，可忽略）"
fi

echo "==> [4/6] 配置 Blutter 命令"
chmod +x /root/flutter-re/blutter/blutter.py
ln -sf /root/flutter-re/blutter/blutter.py /usr/local/bin/blutter 2>/dev/null || true
grep -q 'alias blutter=' /root/.profile 2>/dev/null || echo 'alias blutter="python3 /root/flutter-re/blutter/blutter.py"' >> /root/.profile

echo "==> [5/6] rizin（二进制/ELF 分析，可选）"
if command -v rizin >/dev/null 2>&1; then
    echo "  已安装，跳过"
else
    apt-get install -y rizin 2>/dev/null && echo "  rizin 已安装" || echo "  （rizin 安装失败可忽略，可用 readelf/objdump）"
fi

# 安装完成标记
date > "$MARK"
echo "==> [6/6] 完成！"
echo "------------------------------------------------------------"
echo "  已就绪工具："
echo "    · Blutter      —— Dart AOT 还原/反汇编（核心）"
echo "    · frida-tools  —— 动态插桩（需 root 配合 frida-server）"
echo "    · rizin/r2     —— 二进制分析"
echo "    · binutils     —— readelf/objdump/strings"
echo ""
echo "  Blutter 使用步骤："
echo "    1) 解压目标 APK：       unzip target.apk -d app"
echo "    2) 运行 Blutter："
echo "       python3 /root/flutter-re/blutter/blutter.py app/lib/arm64-v8a /root/out"
echo "       （首次分析某 Dart 版本会自动下载 Dart 源码并编译，耗时较长）"
echo "    3) 输出在 /root/out/ 下：asm/ 反汇编、objs.txt、pp.txt、blutter_frida.js"
echo "------------------------------------------------------------"
