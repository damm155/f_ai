# FBox Flutter 逆向工具链

手机端 Flutter 应用逆向工具集，预置在 `/root/flutter-re/`。

## 安装

```sh
sh /root/flutter-re/setup.sh
```

安装内容包括：python3/pip、gcc 13、cmake、ninja、libicu、libcapstone、
binutils、rizin、frida-tools、Blutter 源码。

## Blutter 用法（核心）

1. 把目标 APK 放到容器（例如通过 App 文件传输/下载）
2. 解压 APK：
   ```sh
   unzip target.apk -d app
   ```
3. 运行 Blutter（自动识别 Dart 版本）：
   ```sh
   cd /root/flutter-re/blutter
   python3 blutter.py app/lib/arm64-v8a /root/out
   ```
   - 第一次分析某个 Dart 版本时，会自动 git clone Dart SDK 源码并用 cmake/ninja 编译，耗时较长（建议在夜间/充电时执行）
   - 编译产物缓存在 `blutter/bin/`，之后同版本无需再编译
4. 输出结果：
   - `out/asm/*`：带符号的反汇编代码
   - `out/objs.txt`：对象池完整 dump
   - `out/pp.txt`：所有 Dart 对象
   - `out/blutter_frida.js`：针对目标 App 的 Frida 脚本模板

## 其他工具速查

| 工具 | 用途 | 示例 |
|---|---|---|
| unzip | 解包 APK | `unzip app.apk -d app` |
| readelf/objdump | ELF 分析 | `readelf -h libapp.so` |
| strings | 提取字符串 | `strings -n 8 libapp.so` |
| rizin | 二进制分析 | `rz-bin -I libapp.so` |
| frida-tools | 动态插桩（需 root+frida-server） | `frida-ps -U` |
| jadx（可选） | Java 层反编译 | 需安装 openjdk |

## 提速建议

- 预编译的 blutter 二进制放在 `blutter/bin/`，若没有你的目标 Dart 版本则需要编译
- 编译时确保 `/root/flutter-re/blutter/dartsdk` 空间充足（约 1-2GB）
- 若空间不足：`du -sh /root/flutter-re/blutter/*` 检查，`dartsdk/`、`build/`、`packages/` 均可删除，下次会自动重建
