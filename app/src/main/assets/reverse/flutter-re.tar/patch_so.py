
#!/usr/bin/env python3
import argparse, os, shutil, subprocess, sys, tempfile

sys.path.insert(0, "/root/so-tool")
from so_tool import SoCtx, prepare_patches, apply_patches

def die(msg):
    print("✗ " + msg)
    sys.exit(1)

def parse_addr(s):
    s = s.strip()
    try:
        addr = int(s, 16) if s.startswith(("0x", "0X")) else int(s)
        if addr < 0:
            raise ValueError
        return addr
    except ValueError:
        die("地址格式错误: %s（请用 0x 开头的十六进制）" % s)

def assemble(insn_text, base_addr=0):
    import re
    # 预处理：把「分支到绝对地址」（b/bl/b.cond/cbz/cbnz/tbz/tbnz #0x目标）转换为
    # 相对形式「. + 偏移」，让 as 按当前 PC 正确编码 arm64 相对分支。
    # GNU as 中 "b #0x..." 会把 #0x 当作立即数偏移而非目标地址（编码错误），
    # 这里逐条指令跟踪当前地址并计算真实偏移。
    # base_addr = 补丁写入的起始虚拟地址；cur = 当前指令相对段首偏移(4字节/条)
    lines = []
    cur = 0
    for one in insn_text.split(";"):
        one = one.strip()
        if not one:
            continue
        m = re.match(
            r"^(b\.(eq|ne|cs|hs|cc|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le|al|nv)|bl|b|cbz|cbnz|tbz|tbnz)(?=\s)"
            r"(.*?)(#?\s*0x[0-9a-fA-F]+)\s*$",
            one,
        )
        if m:
            op = m.group(1)
            rest = m.group(3)  # 如 " w0, #4, " 或 " x0, "
            target_txt = m.group(4).replace("#", "").replace(" ", "")
            try:
                target = int(target_txt, 16)
            except ValueError:
                lines.append(one)
                cur += 4
                continue
            # 当前指令绝对地址 = base_addr + cur；相对偏移 = target - 当前绝对地址
            rel = target - (base_addr + cur)
            if op.startswith("tbz") or op.startswith("tbnz"):
                rest_clean = rest.rstrip(", ").rstrip()
                lines.append("%s %s, . + %d" % (op, rest_clean, rel))
            elif op.startswith("cbz") or op.startswith("cbnz"):
                rest_clean = rest.rstrip(", ").rstrip()
                lines.append("%s %s, . + %d" % (op, rest_clean, rel))
            else:
                # b / bl / b.cond —— 条件码必须保留（op 原样拼回）。
                # 写成 b . + rel 会把 b.eq/b.ls 等降级为无条件跳转，直接改变执行流。
                if op.startswith("b."):
                    # b.cond 相对偏移范围 ±1MB（imm19 * 4），超出则报错而不是默默写坏
                    if not (-1048576 <= rel <= 1048572):
                        die("条件分支超出 ±1MB 范围: %s . + %d" % (op, rel))
                lines.append("%s . + %d" % (op, rel))
            cur += 4
        else:
            lines.append(one)
            cur += 4
    with tempfile.TemporaryDirectory() as td:
        s_path = os.path.join(td, "p.s")
        o_path = os.path.join(td, "p.o")
        b_path = os.path.join(td, "p.bin")
        with open(s_path, "w") as f:
            f.write(".text\n.global _start\n_start:\n")
            for one in lines:
                f.write("  " + one + "\n")
        assembler = "as" if os.uname().machine in ("aarch64", "arm64") else "aarch64-linux-gnu-as"
        objcopy = "objcopy" if assembler == "as" else "aarch64-linux-gnu-objcopy"
        if shutil.which(assembler) is None or shutil.which(objcopy) is None:
            die("缺少 GNU AArch64 as/objcopy")
        r = subprocess.run([assembler, "-o", o_path, s_path], capture_output=True, text=True)
        if r.returncode != 0:
            die("汇编失败: " + (r.stderr or "").strip())
        r = subprocess.run([objcopy, "-O", "binary", "--only-section=.text", o_path, b_path], capture_output=True, text=True)
        if r.returncode != 0:
            die("提取机器码失败: " + (r.stderr or "").strip())
        with open(b_path, "rb") as f:
            return f.read()

def hex_to_bytes(s):
    s = s.replace("0x", "").replace(",", " ").replace("\\x", " ").strip()
    parts = s.split()
    try:
        return bytes(int(p, 16) for p in parts)
    except ValueError:
        die("hex 字节格式错误，示例: 20 00 80 52 C0 03 5F D6")

def format_bytes(b):
    return " ".join("%02X" % x for x in b)

def patch_file(so_path, vaddr, patch_bytes, out_path):
    ctx = SoCtx(so_path)
    try:
        if ctx.machine != "EM_AARCH64" or not ctx.elf.little_endian:
            die("仅支持小端 ARM64 ELF")
        plan = prepare_patches(ctx, [(vaddr, patch_bytes)])
    finally:
        ctx.f.close()
    rid = apply_patches(so_path, plan, out_path)
    print("✓ 已记入补丁柜: %s" % rid)
    _addr, off, old, _data, _sec = plan[0]
    return off, old

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("so")
    ap.add_argument("addr")
    ap.add_argument("patch")
    ap.add_argument("--bytes", action="store_true")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    if not os.path.exists(args.so):
        die("SO 文件不存在: %s" % args.so)
    vaddr = parse_addr(args.addr)
    patch_bytes = hex_to_bytes(args.patch) if args.bytes else assemble(args.patch, vaddr)
    if not patch_bytes:
        die("补丁内容为空")
    if len(patch_bytes) % 4 != 0:
        die("arm64 指令长度必须是 4 的倍数（当前 %d 字节）" % len(patch_bytes))
    out_path = args.out or args.so
    off, old = patch_file(args.so, vaddr, patch_bytes, out_path)
    print("✓ 目标: %s" % args.so)
    print("✓ 虚拟地址: 0x%x -> 文件偏移: 0x%x" % (vaddr, off))
    print("✓ 原字节: %s" % format_bytes(old))
    print("✓ 新字节: %s" % format_bytes(patch_bytes))
    print("✓ 备份: %s.orig / %s.bak" % (out_path, out_path))
    print("✓ 已写入: %s" % out_path)

if __name__ == "__main__":
    main()
