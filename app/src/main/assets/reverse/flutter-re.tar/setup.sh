#!/bin/sh
# ============================================================
#  Flutter 逆向工具链一键安装脚本（精简版，AiCode 移植）
#  适用于 Debian Linux arm64（proot 容器）
#  运行方式：sh /root/flutter-re/setup.sh
#  特性：已安装的组件自动跳过，不会重复下载/升级，秒级完成
#
#  与 FBox 原版的差异（用户决策）：
#   · 去掉 frida-tools（[3/6]）——用户用外部 MCP Frida，容器内这套只拖慢首次分析、
#     且每次新容器都要联网 pip 装一大串（150s+）。
#   · 去掉 rizin（[5/6]）——blutter 不依赖它；ELF 分析由 so_tool（pyelftools+capstone）
#     与 binutils 覆盖，无需再装一个反编译框架。
#  blutter 编译真正需要的只有：[1/6] apt 编译链 + [2/6] pyelftools。
# ============================================================
set -e
PYPI="https://mirrors.aliyun.com/pypi/simple/"
MARK=/root/flutter-re/.installed

echo "==> 检测已安装状态…"
if [ -f "$MARK" ] && command -v cmake >/dev/null 2>&1; then
    echo "工具链已安装（检测到 $MARK）。"
    echo "如需强制重装，请先执行： rm -f $MARK"
    exit 0
fi

echo "==> [1/4] 编译与基础工具（只补装缺失组件，避免重复升级）"
# Debian 用 dpkg-query 判断包是否已安装；rootfs 已预装大部分，此处兜底补装缺失项
missing=""
for p in python3 python3-pip git cmake ninja-build gcc g++ make pkg-config libicu-dev libcapstone-dev binutils file unzip curl ca-certificates; do
    dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q 'install ok installed' || missing="$missing $p"
done
if [ -n "$missing" ]; then
    echo "  需安装:$missing"
    apt-get update >/dev/null 2>&1
    DEBIAN_FRONTEND=noninteractive apt-get install -y $missing
else
    echo "  全部已安装，跳过"
fi

echo "==> [2/4] Python 依赖（pyelftools/requests/dill/capstone）"
if python3 -c "import pyelftools, requests, dill, capstone" 2>/dev/null; then
    echo "  已安装，跳过"
else
    pip3 install --break-system-packages -i "$PYPI" pyelftools requests dill capstone
fi

echo "==> [3/4] 配置 Blutter 命令"
chmod +x /root/flutter-re/blutter/blutter.py
ln -sf /root/flutter-re/blutter/blutter.py /usr/local/bin/blutter 2>/dev/null || true
grep -q 'alias blutter=' /root/.profile 2>/dev/null || echo 'alias blutter="python3 /root/flutter-re/blutter/blutter.py"' >> /root/.profile

# 安装完成标记
date > "$MARK"
echo "==> [4/4] 完成！"
echo "------------------------------------------------------------"
echo "  已就绪工具："
echo "    · Blutter      —— Dart AOT 还原/反汇编（核心）"
echo "    · binutils     —— readelf/objdump/strings"
echo "    · so_tool      —— ELF 摘要/符号/JNI/反汇编/补丁（aicode-so）"
echo ""
echo "  Blutter 使用步骤："
echo "    aicode-blutter <apk 路径> [输出目录]"
echo "    （首次分析某 Dart 版本会自动下载 Dart 源码并编译，耗时较长）"
echo "    输出在 /root/out/ 下：asm/ 反汇编、objs.txt、pp.txt、blutter_frida.js"
echo "------------------------------------------------------------"
