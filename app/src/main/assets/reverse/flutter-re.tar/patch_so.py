
#!/usr/bin/env python3
import argparse, os, shutil, struct, subprocess, sys, tempfile, zipfile, zlib

def die(msg):
    print("✗ " + msg)
    sys.exit(1)

def parse_addr(s):
    s = s.strip()
    if s.startswith(("0x", "0X")):
        return int(s, 16)
    try:
        return int(s)
    except ValueError:
        die("地址格式错误: %s（请用 0x 开头的十六进制）" % s)

def virt_to_offset(data, vaddr):
    if data[:4] != b"\x7fELF":
        die("不是有效的 ELF 文件")
    if data[4] != 2:
        die("仅支持 64 位 ELF")
    if data[5] != 1:
        die("仅支持小端 ELF")
    e_phoff = struct.unpack_from("<Q", data, 0x20)[0]
    e_phentsize = struct.unpack_from("<H", data, 0x36)[0]
    e_phnum = struct.unpack_from("<H", data, 0x38)[0]
    for i in range(e_phnum):
        off = e_phoff + i * e_phentsize
        p_type = struct.unpack_from("<I", data, off)[0]
        if p_type == 1:
            p_offset = struct.unpack_from("<Q", data, off + 8)[0]
            p_vaddr = struct.unpack_from("<Q", data, off + 16)[0]
            p_filesz = struct.unpack_from("<Q", data, off + 32)[0]
            if p_vaddr <= vaddr < p_vaddr + p_filesz:
                return p_offset + (vaddr - p_vaddr)
    die("虚拟地址 0x%x 不在任何可加载段内" % vaddr)

def assemble(insn_text, base_addr=0):
    import re
    # 预处理：把「分支到绝对地址」（b/bl/b.cond/cbz/cbnz/tbz/tbnz #0x目标）转换为
    # 相对形式「. + 偏移」，让 as 按当前 PC 正确编码 arm64 相对分支。
    # GNU as 中 "b #0x..." 会把 #0x 当作立即数偏移而非目标地址（编码错误），
    # 这里逐条指令跟踪当前地址并计算真实偏移。
    # base_addr = 补丁写入的起始虚拟地址；cur = 当前指令相对段首偏移(4字节/条)
    lines = []
    cur = 0
    for one in insn_text.split(";"):
        one = one.strip()
        if not one:
            continue
        m = re.match(
            r"^(b|bl|b\.(eq|ne|cs|hs|cc|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le|al|nv)|cbz|cbnz|tbz|tbnz)\b"
            r"(.*?)(#?\s*0x[0-9a-fA-F]+)\s*$",
            one,
        )
        if m:
            op = m.group(1)
            rest = m.group(3)  # 如 " w0, #4, " 或 " x0, "
            target_txt = m.group(4).replace("#", "").replace(" ", "")
            try:
                target = int(target_txt, 16)
            except ValueError:
                lines.append(one)
                cur += 4
                continue
            # 当前指令绝对地址 = base_addr + cur；相对偏移 = target - 当前绝对地址
            rel = target - (base_addr + cur)
            if op.startswith("tbz") or op.startswith("tbnz"):
                rest_clean = rest.rstrip(", ").rstrip()
                lines.append("%s %s, . + %d" % (op, rest_clean, rel))
            elif op.startswith("cbz") or op.startswith("cbnz"):
                rest_clean = rest.rstrip(", ").rstrip()
                lines.append("%s %s, . + %d" % (op, rest_clean, rel))
            else:
                # b / bl / b.cond —— 条件码必须保留（op 原样拼回）。
                # 写成 b . + rel 会把 b.eq/b.ls 等降级为无条件跳转，直接改变执行流。
                if op.startswith("b."):
                    # b.cond 相对偏移范围 ±1MB（imm19 * 4），超出则报错而不是默默写坏
                    if not (-1048576 <= rel <= 1048572):
                        die("条件分支超出 ±1MB 范围: %s . + %d" % (op, rel))
                lines.append("%s . + %d" % (op, rel))
            cur += 4
        else:
            lines.append(one)
            cur += 4
    with tempfile.TemporaryDirectory() as td:
        s_path = os.path.join(td, "p.s")
        o_path = os.path.join(td, "p.o")
        b_path = os.path.join(td, "p.bin")
        with open(s_path, "w") as f:
            f.write(".text\n.global _start\n_start:\n")
            for one in lines:
                f.write("  " + one + "\n")
        r = subprocess.run(["as", "-o", o_path, s_path], capture_output=True, text=True)
        if r.returncode != 0:
            die("汇编失败: " + (r.stderr or "").strip())
        r = subprocess.run(["objcopy", "-O", "binary", "--only-section=.text", o_path, b_path], capture_output=True, text=True)
        if r.returncode != 0:
            die("提取机器码失败: " + (r.stderr or "").strip())
        with open(b_path, "rb") as f:
            return f.read()

def hex_to_bytes(s):
    s = s.replace("0x", "").replace(",", " ").replace("\\x", " ").strip()
    parts = s.split()
    try:
        return bytes(int(p, 16) for p in parts)
    except ValueError:
        die("hex 字节格式错误，示例: 20 00 80 52 C0 03 5F D6")

def format_bytes(b):
    return " ".join("%02X" % x for x in b)

def patch_file(so_path, vaddr, patch_bytes, out_path):
    with open(so_path, "rb") as f:
        data = bytearray(f.read())
    off = virt_to_offset(bytes(data), vaddr)
    old = bytes(data[off:off + len(patch_bytes)])
    if len(old) < len(patch_bytes):
        die("补丁越界：目标地址剩余 %d 字节，需要 %d 字节" % (len(old), len(patch_bytes)))
    if out_path == so_path:
        shutil.copy2(so_path, so_path + ".bak")
    data[off:off + len(patch_bytes)] = patch_bytes
    with open(out_path, "wb") as f:
        f.write(data)
    with open(out_path, "rb") as f:
        check = f.read()[off:off + len(patch_bytes)]
    if check != patch_bytes:
        die("写入校验失败")
    return off, old

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("so")
    ap.add_argument("addr")
    ap.add_argument("patch")
    ap.add_argument("--bytes", action="store_true")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    if not os.path.exists(args.so):
        die("SO 文件不存在: %s" % args.so)
    vaddr = parse_addr(args.addr)
    patch_bytes = hex_to_bytes(args.patch) if args.bytes else assemble(args.patch, vaddr)
    if not patch_bytes:
        die("补丁内容为空")
    if len(patch_bytes) % 4 != 0:
        die("arm64 指令长度必须是 4 的倍数（当前 %d 字节）" % len(patch_bytes))
    out_path = args.out or args.so
    off, old = patch_file(args.so, vaddr, patch_bytes, out_path)
    print("✓ 目标: %s" % args.so)
    print("✓ 虚拟地址: 0x%x -> 文件偏移: 0x%x" % (vaddr, off))
    print("✓ 原字节: %s" % format_bytes(old))
    print("✓ 新字节: %s" % format_bytes(patch_bytes))
    if out_path == args.so:
        print("✓ 备份: %s.bak" % args.so)
    print("✓ 已写入: %s" % out_path)

if __name__ == "__main__":
    main()
