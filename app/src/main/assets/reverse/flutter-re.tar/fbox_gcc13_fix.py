
import os, re, glob

BASE = '/root/flutter-re/blutter'
PAT = re.compile(r'reinterpret_cast\s*<\s*((?:const\s+)?[A-Za-z_][A-Za-z0-9_:]*(?:\s*\*)*)\s*>\s*\(\s*NULL\s*\)')


def fix_tree(root):
    n = 0
    for dirpath, _, files in os.walk(root):
        for fn in files:
            if not fn.endswith(('.cc', '.h', '.cpp', '.hpp')):
                continue
            f = os.path.join(dirpath, fn)
            try:
                src = open(f, encoding='utf-8', errors='ignore').read()
                new = PAT.sub(lambda m: 'static_cast<%s>(nullptr)' % m.group(1), src)
                if new != src:
                    open(f, 'w', encoding='utf-8').write(new)
                    n += 1
            except Exception:
                pass
    return n


# 在源码文件头部插入 _LARGEFILE64_SOURCE 定义（仅对实际用到 off64_t/pread64 的文件，幂等）
def fix_largefile64(root):
    n = 0
    marker = '#define _LARGEFILE64_SOURCE 1'
    for dirpath, _, files in os.walk(root):
        for fn in files:
            if not fn.endswith(('.cc', '.h', '.cpp', '.hpp')):
                continue
            f = os.path.join(dirpath, fn)
            try:
                src = open(f, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            # 只用在这些文件上修补：出现 off64_t 或 pread64 且尚未定义宏
            if ('off64_t' not in src and 'pread64' not in src):
                continue
            if marker in src:
                continue
            # 找首个 #include 或 #ifndef 等预处理器行，插到它之前；否则插到文件头
            lines = src.splitlines(True)
            idx = None
            for i, ln in enumerate(lines):
                if ln.lstrip().startswith('#'):
                    idx = i
                    break
            if idx is None:
                lines.insert(0, marker + '\n')
            else:
                lines.insert(idx, marker + '\n')
            try:
                open(f, 'w', encoding='utf-8').write(''.join(lines))
                n += 1
            except Exception:
                pass
    return n


fixed = 0
fixed64 = 0
for d in glob.glob(os.path.join(BASE, 'dartsdk', '*')):
    fixed += fix_tree(d)
    fixed64 += fix_largefile64(d)

p = os.path.join(BASE, 'dartvm_fetch_build.py')
if os.path.isfile(p):
    try:
        s = open(p, encoding='utf-8', errors='ignore').read()
        if 'FBOX_GCC13_FIX' not in s:
            hook = r'''
# FBOX_GCC13_FIX: GCC13 下 reinterpret_cast<T>(NULL) 非法，改为 static_cast<T>(nullptr)
# FBOX_LARGEFILE64_FIX: 新版 Dart 的 os_linux.cc 用 off64_t/pread64，需 _LARGEFILE64_SOURCE
def fbox_gcc13_fix(dartsdk_dir):
    import os, re
    _pat = re.compile(r'reinterpret_cast\s*<\s*((?:const\s+)?[A-Za-z_][A-Za-z0-9_:]*(?:\s*\*)*)\s*>\s*\(\s*NULL\s*\)')
    _marker = '#define _LARGEFILE64_SOURCE 1'
    _n = 0
    for _root, _, _files in os.walk(dartsdk_dir):
        for _fn in _files:
            if not _fn.endswith(('.cc', '.h', '.cpp', '.hpp')):
                continue
            _f = os.path.join(_root, _fn)
            try:
                _src = open(_f, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            _new = _pat.sub(lambda m: 'static_cast<%s>(nullptr)' % m.group(1), _src)
            if _new != _src:
                try:
                    open(_f, 'w', encoding='utf-8').write(_new)
                    _n += 1
                except Exception:
                    pass
                _src = _new
            if 'off64_t' in _src or 'pread64' in _src:
                if _marker not in _src:
                    _lines = _src.splitlines(True)
                    _idx = None
                    for _i, _ln in enumerate(_lines):
                        if _ln.lstrip().startswith('#'):
                            _idx = _i
                            break
                    if _idx is None:
                        _lines.insert(0, _marker + '\n')
                    else:
                        _lines.insert(_idx, _marker + '\n')
                    try:
                        open(_f, 'w', encoding='utf-8').write(''.join(_lines))
                        _n += 1
                    except Exception:
                        pass
    return _n
'''
            s = s.replace('def cmake_dart(', hook + '\ndef cmake_dart(', 1)
            s = s.replace(
                '    cmake_dart(info, outdir)',
                '    try:\n        fbox_gcc13_fix(outdir)\n    except Exception:\n        pass\n    cmake_dart(info, outdir)',
                1)
            open(p, 'w', encoding='utf-8').write(s)
            print('OK: dartvm_fetch_build.py 已注入 GCC13 + LARGEFILE64 兼容钩子')
        else:
            print('OK: GCC13 钩子已存在')
    except Exception as e:
        print('WARN: 注入失败', e)

print('OK: 编译兼容修补完成，已修补 reinterpret_cast 文件数 =', fixed, '，largefile64 文件数 =', fixed64)
